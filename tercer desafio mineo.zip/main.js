import express from "express";
import { item1, item2, item3 } from "./productos.js";
import { Contenedor } from "./segundoDesafio.js";
import * as fs from "fs";

const app = express();

const PORT = process.env.PORT || 8080;

const items = new Contenedor("./productosSegundoDesafio.txt");

const createInstances = async (items) => {
  await items.save(items.item1);
  await items.save(items.item2);
  await items.save(items.item3);
};

app.use("/products", async (req, res) => {
  let contenido = await items.getAll();
  res.send(JSON.stringify(contenido, null, 2));
});

app.use("/productoRandom", async (req, res) => {
  let contenido = await items.getAll();
  let randomIndex = Math.floor(Math.random() * contenido.length);
  res.send(JSON.stringify(contenido[randomIndex], null, 2));
});

app.listen(PORT, () => {
  createInstances(items);
  console.log(`puerto del servidor: ${PORT}`);
});


